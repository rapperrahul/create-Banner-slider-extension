<?php

namespace Krisha\Banner\Api;

/**
 * Interface BannerRepositoryInterface
 *
 * PHP version 7
 *
 * @category Krisha
 * @package  Krisha_Banner
 * @author   Krisha <magento@krishaweb.com>
 * @license  https://www.krishaweb.com  Open Software License (OSL 3.0)
 * @link     https://www.krishaweb.com
 */
interface BannerRepositoryInterface
{
    /**
     * Retrieve Banner.
     *
     * @param int $bannerId
     * @return \Krisha\Banner\Api\Data\BannerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($bannerId);

    /**
     * Delete Banner.
     *
     * @param \Krisha\Banner\Api\Data\BannerInterface $banner
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Krisha\Banner\Api\Data\BannerInterface $banner);

    /**
     * Delete Banner by ID.
     *
     * @param int $bannerId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($bannerId);
}
