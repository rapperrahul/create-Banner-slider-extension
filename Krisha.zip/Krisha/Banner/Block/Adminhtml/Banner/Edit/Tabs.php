<?php
/**
 * Class Tabs
 *
 * PHP version 7
 *
 * @category Krisha
 * @package  Krisha_Banner
 * @author   Krisha <magento@krishaweb.com>
 * @license  https://www.krishaweb.com  Open Software License (OSL 3.0)
 * @link     https://www.krishaweb.com
 */
namespace Krisha\Banner\Block\Adminhtml\Banner\Edit;

/**
 * Class Tabs
 *
 * @category Krisha
 * @package  Krisha_Banner
 * @author   Krisha <magento@krishaweb.com>
 * @license  https://www.krishaweb.com  Open Software License (OSL 3.0)
 * @link     https://www.krishaweb.com
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('Banner_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Banner Information'));
    }
}
