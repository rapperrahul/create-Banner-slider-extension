var config = {
    map: {
        '*': {
            "slick": 'Krisha_Banner/js/slick',
        }
    }
};
