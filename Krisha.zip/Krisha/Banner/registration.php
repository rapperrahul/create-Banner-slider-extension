<?php
/**
 * Krisha Banner
 *
 * PHP version 7
 *
 * @category Krisha
 * @package  Krisha_Banner
 * @author   Krisha <magento@krishaweb.com>
 * @license  https://www.krishaweb.com/  Open Software License (OSL 3.0)
 * @link     https://www.krishaweb.com/
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Krisha_Banner',
    __DIR__
);
