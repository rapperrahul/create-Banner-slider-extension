<?php
/**
 * Class Edit
 *
 * PHP version 7
 *
 * @category Krisha
 * @package  Krisha_Banner
 * @author   Krisha <magento@krishaweb.com>
 * @license  https://www.krishaweb.com  Open Software License (OSL 3.0)
 * @link     https://www.krishaweb.com
 */
namespace Krisha\Banner\Controller\Adminhtml\Banner;

/**
 * Class Edit
 *
 * @category Krisha
 * @package  Krisha_Banner
 * @author   Krisha <magento@krishaweb.com>
 * @license  https://www.krishaweb.com  Open Software License (OSL 3.0)
 * @link     https://www.krishaweb.com
 */
class Edit extends \Krisha\Banner\Controller\Adminhtml\Banner
{
    protected $allowedKey = "Krisha_Banner::edit_banner";
}
